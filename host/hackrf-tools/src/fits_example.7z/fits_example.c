#include "fitsio.h"
#include "time.h"
#include <string.h>
void  updateHeadersFitsFile(fitsfile *fptr, int status)
{
    /*Write a keyword; must pass the ADDRESS of the value*/
    long exposure = 1500.;
    time_t now = time(0);
    char *time_str = ctime(&now);
    time_str[strlen(time_str)-1] = '\0';
  
    fits_update_key(fptr,TSTRING,"DATE", time_str,"Time of observation" ,&status); //Date observation
    fits_update_key(fptr,TSTRING, "OBJECT", "Space", "Object name", &status ); //Object Description
    fits_update_key(fptr,TSTRING, "ORIGIN", "TFM Alejandro", "Property", &status ); //Organization name
    fits_update_key(fptr,TSTRING, "CTYPE1", "Amp(dB)", "Power (dB)", &status ); //Title axis 1
    fits_update_key(fptr,TSTRING, "CTYPE2", "Frequency[MHz]", "MHz", &status ); //Title axis 2
    fits_update_key(fptr,TLONG,"EXPOSURE", &exposure, "Total Exposure Time", &status);
}

int main(int argc, char const *argv[])
{
    fitsfile *fptr;
    int status = 0, ii, jj;
    long fpixel = 1, naxis = 2, nElements, exposure;
    long naxes[2] = {400,200};
    short array[200][400];
    
    /*Create new file*/
    fits_create_file(&fptr, "testfile_newHeaders.fits", &status);

    /*create the primary array image (16-bit short integer pixels*/
    fits_create_img(fptr, SHORT_IMG, naxis, naxes, &status);


    updateHeadersFitsFile(fptr, status);
    
    /*Initialize the values in the image with a linear ramp function*/
    for(jj=0; jj<naxes[1]; jj++)
    {
        for(ii =0; ii < naxes[0]; ii++)
        {
            array[jj][ii] = ii + jj;

        }
    }

    nElements = naxes[0] * naxes[1];

    /*Write the array of integers of the image*/
    fits_write_img(fptr, TSHORT, fpixel, nElements, array[0], &status);
    
    /*Close and report any error*/
    fits_close_file(fptr, &status);
    fits_report_error(stderr, status);

    return status;
}
